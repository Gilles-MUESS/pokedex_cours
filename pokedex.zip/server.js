const fs = require("fs");
const express = require("express");
const app = express();
const port = 3000;

let database = JSON.parse(fs.readFileSync("pokedex.json"));

app.get("/types", (req, res) => {
  res.send(database.types);
});
// app.get("/pokemons", (req, res) => {
//   res.send(database.pokemons);
// });
app.get("/pokemons/:filter", (req, res) => {
  const filter = req.params.filter;

  switch (filter) {
    case "plante":
      let filteredPokemons = database.pokemons.find(
        (pokemon) =>
          pokemon.types.nom == filter.charAt(0).toUpperCase() + filter.slice(1)
      );
      console.log(filteredPokemons);
      res.send(filteredPokemons);
      break;
    case "all":
      res.send(database.pokemons);
      break;
    default:
      res.send(database.pokemons);
      break;
  }
});
// app.get("/pokemons/names", (req, res) => {
//   const names = [];
//   for (let pokemon of database.pokemons) {
//     names.push(pokemon.nom);
//   }
//   res.send(names);
// });

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
